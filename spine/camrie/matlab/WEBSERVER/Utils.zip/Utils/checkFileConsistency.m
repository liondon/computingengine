function[]=checkFileConsistency(f,type,jot)
%test if a file is correct v0


DEF=[]

if()

myjsonWrite()

end
