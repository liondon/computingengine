function im=reconITSOS(x,enc,rec)
x(isnan(x))=0;

im = fftshift(ifft(fftshift(x,1),[],1),1);
% Chop if needed
% Reconstruct in y then z
im = fftshift(ifft(fftshift(im,2),[],2),2);

im=im*sqrt(size(x,1)*size(x,2));

%                        this.ChanIm=im;
% Combine SOS across coils
im = sqrt(sum(abs(im).^2,3));


if (exist('enc','var') & exist('rec','var') )
                ind1 = floor((enc.Nx - rec.Nx)/2)+1;
            ind2 = floor((enc.Nx - rec.Nx)/2)+rec.Nx;
            im=im(ind1:ind2,:);
            
end
end

