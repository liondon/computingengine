function im=reconIT3D(x)
x(isnan(x))=0;

im = fftshift(ifft(fftshift(x,1),[],1),1);
% Chop if needed
% Reconstruct in y then z
im = fftshift(ifft(fftshift(im,2),[],2),2);

im = fftshift(ifft(fftshift(im,3),[],3),3);


%                        this.ChanIm=im;
% Combine SOS across coils
im = sqrt(sum(abs(im).^2,4));


