classdef WebReport<handle
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        MainWebsite
        QueryDir
        R
    end
    
    methods
        function this = WebReport(w,q)
            %UNTITLED Construct an instance of this class
            %   Detailed explanation goes here
        
            this.MainWebsite=w;
            this.QueryDir=q;
        end
        
        
        function RE = sendOnWeb(this,Q)
            url=[this.getFullExpressionMainWebsitePlusQuery() '/fastQReturnJson.php?Q=' Q];
            RE=webread(url);
        end
        
        function o = sendOnWebAndDecodeBody(this,url)
         R=this.sendOnWeb(url);
         
         o=jsondecode(R);
        end
        
        function o=getFullExpressionMainWebsitePlusQuery(this)
            o=[this.MainWebsite this.QueryDir ];
        end
    end
end
