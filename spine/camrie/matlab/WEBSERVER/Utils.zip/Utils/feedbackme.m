function user=feedbackme(A,SA,h)
%Area, subarea of the feedback and handles

    
    prompt={'feedback'};
    title='Please write your feedback';
    numlines=4;
    options.WindowStyle='normal';
    options.Interpreter='tex';
    answer=inputdlg(prompt,title,numlines,{''},options);
    
   
        url=['INSERT INTO Feedback( UID, feedback, Area,SubArea) VALUES (''' h.User.getMROPTID() ''',''' answer{1} ''',''' num2str(A) ''',''' num2str(SA) ''')'];
        h.WR.sendOnWeb(url);
h.User.ringrazia();    




end


