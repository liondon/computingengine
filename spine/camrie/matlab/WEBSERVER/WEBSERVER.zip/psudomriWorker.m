function dgfWorker(jop,fout)
%jop is the config file web

%[15 20] non funziona

addpath(genpath(pwd));

%getthejson
o=webread(jop);


[O other]=cm_dgf([o.gridsize.x o.gridsize.y], o.fieldstrength);

ultimatesnr=zeros(size(O.mask_reg2));
snr=zeros(size(O.mask_reg2));

%vabbe sta cosa la devo cambiare..... possibile che da nessuna parte ci sia
%la maschera di sta cosa?
S=regionprops(O.mask_reg2,'all');

sx=S.SubarrayIdx{1}(1):S.SubarrayIdx{1}(end);
sy=S.SubarrayIdx{2}(1):S.SubarrayIdx{2}(end);

ultimatesnr(sx,sy)=O.snr_ult;

snr(sx,sy)=O.snr_coil;

OUTPUT=DGFOutput();
OUTPUT.add2DImagetoExport(ultimatesnr,'ultimate SNR');
OUTPUT.add2DImagetoExport(snr,'coil SNR');

% OUTPUT.exportResults(fout);
OUTPUT.exportResultsAndSettings(fout,other)

clear OUTPUT;

end
