



STARTPOSITION=pwd;

%go to the needed directory
cd GUI2014bEdit/

 %add the path to matlab
addpath(genpath(pwd))

%the option json file
JOPT='/data/WORK/NYUPROJECTS/CM/CAMRIE/matlab/WEBSERVER/GUI2014bEdit/JSONScripts/TestInputFile.json';

w='/data/tmp/'
jLO='~/jlo.json'
jOUT='~/jloOUT.json'
fromjsontobat(JOPT,jOUT,jLO,w)

